import React from "react";

function TaskList({ tasks, updateTaskStatus }) {
  if (!tasks.length) {
    return (
      <div className="text-center text-gray-500 mt-10">
        <p>No tasks found</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {tasks.map((task) => (
        <div
          key={task.id}
          className="border p-4 rounded flex justify-between items-center"
        >
          <span>{task.title}</span>
          <select
            value={task.status}
            onChange={(e) => updateTaskStatus(task.id, e.target.value)}
            className="border rounded px-2 py-1"
          >
            <option>Pending</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
        </div>
      ))}
    </div>
  );
}

export default TaskList;