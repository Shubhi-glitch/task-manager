import React from "react";

function Filter({ filter, setFilter }) {
  const filters = ["All", "Pending", "In Progress", "Completed"];
  return (
    <div className="mb-4 flex gap-2">
      {filters.map((f) => (
        <button
          key={f}
          onClick={() => setFilter(f)}
          className={\`px-4 py-2 rounded border \${
            f === filter
              ? "bg-blue-500 text-white"
              : "bg-white text-black border-gray-300"
          }\`}
        >
          {f}
        </button>
      ))}
    </div>
  );
}

export default Filter;