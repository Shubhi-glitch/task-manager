import React, { useEffect, useState } from "react";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Filter from "./components/Filter";

function App() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
    setTasks(savedTasks);
  }, []);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const updateTaskStatus = (id, status) => {
    setTasks(tasks.map((task) =>
      task.id === id ? { ...task, status: status } : task
    ));
  };

  const filteredTasks =
    filter === "All" ? tasks : tasks.filter((task) => task.status === filter);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold">Task Management</h1>
      <p className="text-gray-500 mb-4">Organize and track your tasks efficiently</p>
      <Filter filter={filter} setFilter={setFilter} />
      <TaskForm addTask={addTask} />
      <TaskList tasks={filteredTasks} updateTaskStatus={updateTaskStatus} />
    </div>
  );
}

export default App;